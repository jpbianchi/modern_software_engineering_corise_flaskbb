# -*- coding: utf-8 -*-
"""
    flaskbb.tokens
    ~~~~~~~~~~~~~~

    :copyright: 2014-2018 the FlaskBB Team
    :license: BSD, see LICENSE for more details
"""

from .serializer import FlaskBBTokenSerializer

__all__ = ("FlaskBBTokenSerializer",)
